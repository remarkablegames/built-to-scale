label day_01:

    stop music fadeout 1
    queue music orchestral_waltz

    scene bg room morning
    with fade

    player "I know dreams are achieved through hard work and dedication,{w=.3} but I have no idea where to begin."

    play sound buzz

    "Your phone buzzes with a notification{w=.3}—an email from a potential supplier."

    player "But as Laozi once said,{w=.3} “{i}A journey of a thousand miles begins with a single step.{/i}”"

    show friend
    with dissolve

    friend @ confident "Thinking about your business,{w=.1} [player_name]?"

    player "It’s all I can think about."
    player "If this works,{w=.1} it could be the start of something big."

    friend "Well,{w=.1} you’ve got the work ethic."
    friend "I’ve seen you juggle everything from school work to family obligations."

    player "Thanks,{w=.1} I’ll need every bit of support I can get."

    friend @ confident2 "Why don’t you take a break?"
    friend @ confident3 "Sometimes it’s good to clear your mind."

    player "That’s not a bad idea."

    friend "Do you want to check out the library,{w=.1} go to the park,{w=.1} or head over to the shop?"

    return
