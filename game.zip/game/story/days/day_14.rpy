label day_14:

    stop music fadeout 1
    queue music electro_1 fadein 1

    scene bg office
    with fade

    "As you’re reviewing your sales reports,{w=.1} you notice something strange."

    player "Wait...{w=.3} these numbers can’t be right."

    show mentor smile2
    with dissolve

    mentor "Surprising,{w=.1} isn’t it?"

    player "What do you mean?"

    mentor "One of your marketing campaigns went viral overnight.{w=.3} Your sales have surged!"

    play sound kaching

    $ money += 4000

    player "That explains it!{w=.3} I’ve just earned {color=#85bb65}$4,000{/color} in a single day!"

    if equity != 100:
        player "You must be enjoying that [100 - equity]%% equity I gave you."
    else:
        player "You must be enjoying the fruits of our labor."

    mentor giveup "Yes I am,{w=.2} yes I am."

    hide mentor with dissolve

    "With an extra $4,000 in your account,{w=.1} your confidence is boosted.{w=.3} Onward and upward."

    return
