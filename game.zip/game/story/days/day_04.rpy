label day_04:

    stop music fadeout 1
    queue music orchestral_waltz

    scene bg office
    with fade

    "You receive an urgent email from one of your suppliers."
    supplier "I’m afraid we’ve encountered some issues with the shipment of your scales."
    supplier "There’s a delay,{w=.1} and it’s going to affect your production."

    player "How long will the delay last?"

    supplier "If we expedite the shipment,{w=.1} it will cost an additional $100."
    supplier "Otherwise,{w=.1} it could take a few days to sort out,{w=.1} and you may see a dip in sales."

    menu:
        "What are you going to do?"

        "Expedite the shipment ({color=#85bb65}-$100{/color}).":
            if money >= 100:
                $ money -= 100

                player "I can’t afford a slowdown in production."
                player "Expedite the shipment."

                supplier "Understood.{w=.3} We’ll ensure your products arrive on time."
            else:
                "You don’t have enough money to cover the expedited shipping cost."

        "Wait for the shipment.":
            $ energy -= 50

            player "I’ll wait it out.{w=.2} Hopefully, it won’t impact my sales too much."

            supplier "Understood.{w=.3} We’ll do our best to get things moving as fast as possible."

    "The email leaves you with a difficult decision,{w=.1} but you’ve made your choice."
    "Now you wait to see what happens."

    return
